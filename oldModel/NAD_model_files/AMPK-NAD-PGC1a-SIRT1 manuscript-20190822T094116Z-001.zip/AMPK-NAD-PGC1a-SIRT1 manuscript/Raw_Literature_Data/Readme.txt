Note that some of the extracted data may be in the supplementary material
of the source publications. To help find the original figures in the
source publications it might be of use to go to the 'Model Development and Validation'
document where the original source Figures extracted from the literature 
appear next to the manuscript figures.